-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : Dim 04 oct. 2020 à 23:25
-- Version du serveur :  10.4.11-MariaDB
-- Version de PHP : 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `projet1`
--

-- --------------------------------------------------------

--
-- Structure de la table `evaluation`
--

CREATE TABLE `evaluation` (
  `numero` int(11) NOT NULL,
  `critere` varchar(200) NOT NULL,
  `valeur` varchar(200) NOT NULL,
  `commentaire` varchar(500) NOT NULL,
  `id_p` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `evaluationglobal`
--

CREATE TABLE `evaluationglobal` (
  `id` int(11) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `mois` varchar(100) NOT NULL,
  `force_employe` varchar(500) NOT NULL,
  `point_ameliorer` varchar(500) NOT NULL,
  `programme_dev` varchar(500) NOT NULL,
  `avis_res_rh` varchar(500) NOT NULL,
  `dec_directeur` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Structure de la table `form`
--

CREATE TABLE `form` (
  `id` int(11) NOT NULL,
  `intitule` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `form`
--

INSERT INTO `form` (`id`, `intitule`) VALUES
(2, 'Qualité'),
(3, 'Fait preuve de rigueur dans le travail\r\n'),
(4, 'S’assure de la qualité de son travail en faisant les\r\nvérifications et les suivis nécessaires. '),
(5, 'Organisation du travail'),
(6, 'Planifie et organise son travail de façon adéquate. '),
(7, 'Utilise efficacement son temps pour réaliser les\r\ntâches qui lui sont confiées. '),
(8, 'Respecte les délais et les échéanciers qui lui sont\r\nfixés '),
(9, 'Prise de décision\r\n'),
(10, 'Cerne efficacement les données d’un problème. '),
(11, 'Propose des solutions possibles aux problèmes\r\nrencontrés. '),
(12, 'Prend les moyens pour atteindre les résultats.'),
(13, 'Attitude et comportement au travail\r\n'),
(14, 'Traite ses collègues et son supérieur avec respect. '),
(15, 'Maintien des relations harmonieuses et collabore\r\navec ses collègues. '),
(16, 'Respecte les politiques et les règlements de\r\nl’entreprise'),
(17, 'Fait preuve d’éthique professionnelle et d’intégrité\r\ndans tous les aspects de son travail. '),
(18, 'Fait preuve de discipline ');

-- --------------------------------------------------------

--
-- Structure de la table `profil`
--

CREATE TABLE `profil` (
  `id` int(11) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `fonction` varchar(200) NOT NULL,
  `anciennete` varchar(200) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `evaluation`
--
ALTER TABLE `evaluation`
  ADD PRIMARY KEY (`numero`);

--
-- Index pour la table `evaluationglobal`
--
ALTER TABLE `evaluationglobal`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `profil`
--
ALTER TABLE `profil`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `evaluation`
--
ALTER TABLE `evaluation`
  MODIFY `numero` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `evaluationglobal`
--
ALTER TABLE `evaluationglobal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `form`
--
ALTER TABLE `form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT pour la table `profil`
--
ALTER TABLE `profil`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
