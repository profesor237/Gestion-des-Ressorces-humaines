Auteur:  Cyril Ngueloh

Durée d'exécution:  du 2/10/200 au 4/10/2020

Cahier de charge:  non spécifié

service:  Gestion des ressources humaine(controle des performances des employés)

Niveau d'utilisation:  très simple, juste bien lire 

Mot de passe: Aucun mot de passe utilisé

Type de licence: Open Source.


                    INSTALLATION ET PRISE EN MAIN

Après dezzipé le fichier, copier le dossier et le mettre dans le htdos de xampp ou wamp. 
En suite activer les serveurs, puis aller sur le navigateur et taper l'adresse: 
localhost/projet1/vue/accueil.php  ça y est!
