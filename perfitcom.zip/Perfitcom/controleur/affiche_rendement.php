
<!DOCTYPE HTML>
<html>
	<head>
		<title> Fiche de rendement du personnel </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=divice-width, initial-scale=1.0">
		<link rel="stylesheet" href="styles/style.css">
	<body>

<?php
echo"<div class='corps'>";
try
{

    $nom1 = $_POST['nom'];
    $debut = $_POST['debut'];
    $fin = $_POST['fin'];
    $nom2="";
    $fonction2="";
    $debut2="";
    $debut2="";
    $fin2="";
    $identite=0;
    $anciennete2="";

    
    $connexion = new PDO("mysql:host=localhost; dbname=projet1","root","");
    $connexion->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    echo"	
    
        
    <div class='comp1'>
            <h4>
               <strong> SERVICE DES RESSOURCES HUMAINES</strong>
            </h4> 
        </div>
        <div class='comp2'>
            <h4> 
            <strong><u>FICHE D’EVALUATION DU RENDEMENT DU PERSONNEL ADMINISTRATIF</u> </strong>

            </h4>
        </div>
        <div>
            <form  method='post' action= 'controleur_accueil.php'>";

    $requete2= $connexion->query(" SELECT id, nom, fonction, anciennete, date_debut, date_fin FROM profil WHERE nom='$nom1' AND date_debut='$debut'  ");
    while($resultat2 = $requete2->fetch()){

                $nom2 = $resultat2['nom'];
                $fonction2 = $resultat2['fonction'];
                $anciennete2 = $resultat2['anciennete'];
                $debut2 = $resultat2['date_debut'];
                $fin2 = $resultat2['date_fin'];
                $identite=$resultat2['id'];

               

                 }
                 echo"
                <label ><strong>NOMS ET PRENOMS:</label>
                <input type='text'  name='nom' size='90' class='input1' 
                value='".$nom2."' style='font-size: 18px'> </input><br><br>
                <label >FONCTION:</label>
                <input type='text' id='lname' name='fonction' size='90' class='input1'
                value='".$fonction2."' style='font-size: 18px'><br><br>
                <label >Ancienneté au poste:</label>
                <input type='text' id='lname' name='anciennete' size='90' class='input1'
                value='".$anciennete2."' style='font-size: 18px'><br><br>
                <label >Période d’évaluation: du</label>
                <input  type='text' name='debut' size='30' value='".$debut2."' style='font-size: 18px'>
                <label >    au    </label>
                <input type='text' id='lname' name='fin' size='30' value='".$fin2."' style='font-size: 18px'>
           
        </div>
        <div>
            <h4>
            LEGENDE D’EVALUATION </strong>
            </h4>
            <div>
                <ul>
                    <li style='margin-left: 100px';> 1 = Ne rencontre pas les attentes <br>  3 = Rencontre les attentes    </li>
                    <li class='legende'>2 = Nécessite une amélioration <br>  4 = Depasse les attentes </li>
 
                </ul>

            </div>  
            
        </div><br>

        <div>

        </div>";

        echo' <table border="1" class="w3-table" id="tab" style="font-size: 18px">
        <tr style="background-color: red">
        <th class="intitule"> CRITERES </th>
        <th> 
            <table>
                <tr> EVALUATION </tr>
                <tr> <th>1</th><th>2</th><th>3</th><th>4</th></tr>
            </table>
        </th>
        <th class="commentaire" style="text-align: center"> COMMENTAIRES</th>
        </tr>
        
        ';
        

            $i=0;
            $j=0;


            $requete1= $connexion->query(" SELECT intitule as inti, intitule, id, commentaire, valeur, id_p FROM form f INNER JOIN evaluation e ON f.intitule=e.critere WHERE e.id_p='$identite'");
            while($resultat1 = $requete1->fetch()){

                $identifiant = $resultat1['id'];
                
                if($j==0)
                {
                    echo '<tr style="background-color: yellow">
                    <th class="intitule">Qualité
                    </th>
                    <th> 
                        <table>
                        <tr>
                        <th></th><th></th> <th></th> <th></th>
                       </tr>
                        </table>
                    </th>
                    <th class="commentaire" > 
                    </th>
                    </tr>';

                }
                elseif($j==2){

                    echo '<tr style="background-color: yellow">
                    <th class="intitule">Organisation du travail
                    </th>
                    <th> 
                        <table>
                        <tr>
                        <th></th><th></th> <th></th> <th></th>
                       </tr>
                        </table>
                    </th>
                    <th class="commentaire" > 
                    </th>
                    </tr>';
                }

                elseif($j==5){

                    echo '<tr style="background-color: yellow">
                    <th class="intitule">Organisation du travail
                    </th>
                    <th> 
                        <table>
                        <tr>
                        <th></th><th></th> <th></th> <th></th>
                       </tr>
                        </table>
                    </th>
                    <th class="commentaire" > 
                    </th>
                    </tr>';
                }

                elseif($j==8){

                    echo '<tr style="background-color: yellow">
                    <th class="intitule">Organisation du travail
                    </th>
                    <th> 
                        <table>
                        <tr>
                        <th></th><th></th> <th></th> <th></th>
                       </tr>
                        </table>
                    </th>
                    <th class="commentaire" > 
                    </th>
                    </tr>';
                }
                
                    $i=$i+1;
                    $statut=$resultat1['valeur'];
                     $stat1="";
                    $stat2="";
                    $stat3="";
                    $stat4="";

                    echo '<tr>
                    <th class="intitule">'.$resultat1['intitule'].'</th>
                    <th> ';
                        

                        if($statut=="Ne rencontre pas les attentes")
                        {
                            
                            echo'   <table>
                            <tr>
                                <input style="margin-left: 10px" class="radio" type="radio" name="qualite'.$i.'" value="Ne rencontre pas les attentes" checked disabled> 
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Nécessite une amélioration" disabled>
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Rencontre les attentes" disabled>
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Depasse les attentes"  disabled> 
                            
                           </tr>
                            </table>
                        </th>';


                        }
                        elseif($statut=="Nécessite une amélioration")
                        {
                            
                            echo'   <table>
                            <tr>
                                <input style="margin-left: 10px" class="radio" type="radio" name="qualite'.$i.'" value="Ne rencontre pas les attentes" disabled> 
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Nécessite une amélioration" checked disabled>
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Rencontre les attentes"  disabled>
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Depasse les attentes"  disabled> 
                            
                           </tr>
                            </table>
                        </th>';

                        }
                        elseif($statut=="Rencontre les attentes")
                        {
                            
                            echo'   <table>
                            <tr>
                                <input style="margin-left: 10px" class="radio" type="radio" name="qualite'.$i.'" value="Ne rencontre pas les attentes" disabled> 
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Nécessite une amélioration"  disabled>
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Rencontre les attentes"  checked disabled>
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Depasse les attentes" disabled > 
                            
                           </tr>
                            </table>
                        </th>';

                        }
                        elseif($statut=="Depasse les attentes")
                        {
            
                            echo'   <table>
                            <tr>
                                <input style="margin-left: 10px" class="radio" type="radio" name="qualite'.$i.'" value="Ne rencontre pas les attentes" disabled> 
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Nécessite une amélioration"  disabled>
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Rencontre les attentes"  disabled>
                                <input style="margin-left: 5px" class="radio" type="radio" name="qualite'.$i.'" value="Depasse les attentes"  checked disabled> 
                            
                           </tr>
                            </table>
                        </th>';

                        }
    
                   



              echo' <th class="commentaire" >
                    <textarea  class="incom" name="commentaire'.$i.'" > '.$resultat1['commentaire'].' </textarea>
                </th>
                  
                </tr>  ' ;

                
                   
                
                
                $j=$j+1;
              
                
            }


        }
        catch(PDOException $e){
            echo " Echec : " .$e->getMessage();
           }

        ?>
        </table> <br><br>
    </body>

</html>