<?php
	session_start();
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title> Fiche d'évaluation globale </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=divice-width, initial-scale=1.0">
		<link rel="stylesheet" href="styles/style.css">
	<body onload="windows.print()">

      
    <?php

    try{

        $nom1 = $_POST['nom'];
        $mois1 = $_POST['mois'];

        $connexion = new PDO("mysql:host=localhost; dbname=projet1","root","");
        $connexion->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

        $requete1= $connexion->query(" SELECT * FROM evaluationglobal WHERE nom='$nom1' AND mois='$mois1' ");
        while($resultat1 = $requete1->fetch()){ 

            echo' <div>
            <br><br><br>
            <form method="post" action="controleur_page2.php">
                <label for="fname"><strong>NOMS ET PRENOMS:</label>
                <input type="text" name="nom" size="90" class="input1" 
                value="'.$resultat1['nom'].'" style="font-size: 20px"> </input><br><br>
    
                <label for="fname"><strong>Mois d evaluation:</label>
                <input type="text"  name="mois" size="90" class="input1" 
                value="'.$resultat1['mois'].'" style="font-size: 20px; " > </input><br><br>
    
                <div>
                    <div class="comp2">
                        <H3>
                        <u> EVALUATION GLOBALE</u>
                        </H3>
                    </div>
    
                    
                    <u> FORCE DE L’EMPLOYE</u><br>
                    <textarea rows="5" cols="110" name="force_emp" style="border: none; font-size: 20px;" >'.$resultat1['force_employe'].' </textarea><br>
    
    
                </div>
                <div>
                    <br><u>POINTS A AMELIORER</u><br> 
    
                        <textarea rows="5" cols="110" name="point_am" style="border: none; font-size: 20px;" > '.$resultat1['point_ameliorer'].' </textarea>
                        <br>
    
                </div>
                <div>
                    <br><u>PROGRAMME DE DEVELOPEMENT </u><br>
                    
                    <textarea rows="5" cols="110" name="programme_dev" style="border: none; font-size: 20px;" >'.$resultat1['programme_dev'].'  </textarea> <br>
    
                </div>
            
    
            <div><br>
    
            <ul>
                        <li style="margin-left: 10px";><u>Signature de l’employé </u>   </li>
                        <li style="margin-left: 78px"> <u>Visa supérieur hiérarchique N°1</u> </li>
                        <li style="margin-left: 78px"> <u>Visa supérieur hiérarchique N°2 </u></u> </li>
     
                    </ul><br><br><br><br><br>
    
            </div>
    
            <div>
    
                <table border="1">
                    <tr style="height:80px;">
                        <td style="width: 400px"> <u>AVIS ET VISA DU RESPONSABLE RH </u></td>
                        <td style="width: 400px"><u>DECISION DU DIRECTEUR </u></td>
                
                    </tr>
                    <tr style="height:100px;">
                        <td>  <textarea rows="5" cols="50" style="border: none; font-size: 20px;" name="avis" > '.$resultat1['avis_res_rh'].'</textarea> 
                        <td> <textarea rows="5" cols="50" style="border: none; font-size: 20px;" name="decision" > '.$resultat1['dec_directeur'].'</textarea> 
    
                    </tr>
    
                </table>
    
            <div>
            
    </form>
            
            <br><br>';

         }

       
    }
catch(PDOException $e){
    echo " Echec : " .$e->getMessage();
   }

?>

     
    </body>
</html>