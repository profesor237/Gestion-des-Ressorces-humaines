<?php
	session_start();
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title> enregistrer une fiche d'évaluation globale </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=divice-width, initial-scale=1.0">
		<link rel="stylesheet" href="styles/style.css">
	<body>
    <div class="entete"><strong style="height: 80px; font-size: 30px; text-shadow: 1px 1px 1px;"> GESTION DES RESSOURCES HUMAINES</strong>
    
    <br><a href="accueil.php" style="text-decoration: none; font-size:20px; color: white;"><strong> Accueil</strong> </a>
    </div>

      
      <div>
        <br><br><br>
        <form method='post' action='../controleur/controleur_page2.php'>
            <label for="fname"><strong>NOMS ET PRENOMS:</label>
            <input type="text" name="nom" size="90" class="input1" 
            placeholder="......................................................................................" style='font-size: 16px' required> </input><br><br>

            <label for="fname"><strong>Mois d'evaluation:</label>
            <input type="text"  name="mois" size="90" class="input1" 
            placeholder="......................................................................................" style='font-size: 16px' required> </input><br><br>

            <div>
                <div class="comp2">
                    <H3>
                    <u> EVALUATION GLOBALE</u>
                    </H3>
                </div>

                
                <u> FORCE DE L’EMPLOYE</u><br>
                <textarea rows="5" cols="110" name="force_emp" style="font-size: 16px" required> </textarea><br>


            </div>
            <div>
                <br><u>POINTS A AMELIORER</u><br> 

                    <textarea rows="5" cols="110" name="point_am" style="font-size: 16px" required> </textarea>
                    <br>

            </div>
            <div>
                <br><u>PROGRAMME DE DEVELOPEMENT </u><br>
                
                <textarea rows="5" cols="110" name="programme_dev" style="font-size: 16px" required>  </textarea> <br>

            </div>
        

        <div><br>

        <ul>
                    <li style="margin-left: 10px";><u>Signature de l’employé </u>   </li>
                    <li style="margin-left: 78px"> <u>Visa supérieur hiérarchique N°1</u> </li>
                    <li style="margin-left: 78px"> <u>Visa supérieur hiérarchique N°2 </u></u> </li>
 
                </ul><br><br><br><br><br>

        </div>

        <div>

            <table border="1">
                <tr style="height:80px;">
                    <td style="width: 400px"> <u>AVIS ET VISA DU RESPONSABLE RH </u></td>
                    <td style="width: 400px"><u>DECISION DU DIRECTEUR </u></td>
            
                </tr>
                <tr style="height:100px;">
                    <td>  <textarea rows="5" cols="50" style="border: none" name="avis" style="font-size: 16px"> </textarea> 
                    <td> <textarea rows="5" cols="50" style="border: none" name="decision" style="font-size: 16px"> </textarea> 

                </tr>

            </table>

        <div>
        <p style="margin-left: 65%"> <button type="submit" style="height: 30px; width: 80px; font-size: 20px; background-color: green; box-shadow: 2px 2px 2px;">Valider </button> </p>
</form>
        
        <br><br>
    </body>

    
</html>