<?php
	session_start();
?>
<!DOCTYPE HTML>
<html>
	<head>
		<title> gestion des ressources humaines </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=divice-width, initial-scale=1.0">
		<link rel="stylesheet" href="styles/w3.css">
	</head>
    
<body>

<div class="w3-container w3-green">
<p>
<div class="w3-tag w3-jumbo w3-red w3-animate-top">R</div>
    <div class="w3-tag w3-jumbo w3-animate-top" >H</div>
    <div class="w3-tag w3-round w3-green w3-animate-bottom" style="border:1px solid white ">
        GESTION DES RESSOURCES HUMAINES
        </div>
</p>
<a href="../vue/accueil.php" style="text-decoration: none; font-size: 25px;"><strong> Accueil </strong></a>
</div>






</body>
<html>

