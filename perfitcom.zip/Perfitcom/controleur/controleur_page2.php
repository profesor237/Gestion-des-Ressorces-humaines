<!DOCTYPE html>
<html>
	<head>
		<title> gestion des buts de la premiere journee </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=divice-width, initial-scale=1.0">
	</head>
	<body>
		<?php
				try{

					$nom1 = $_POST['nom'];
					$mois1 = $_POST['mois'];
					$force_emp1 = $_POST['force_emp'];
					$point_am1 = $_POST['point_am'];
					$programme_dev1 = $_POST['programme_dev'];
					$avis1 = $_POST['avis'];
					$decision1 = $_POST['decision'];



					$connexion = new PDO("mysql:host=localhost; dbname=PROJET1", "root","");
				    $connexion-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

					$requete = $connexion -> exec("INSERT INTO evaluationglobal (nom,mois,force_employe,point_ameliorer,programme_dev,avis_res_rh,dec_directeur) VALUES('$nom1','$mois1','$force_emp1','$point_am1','$programme_dev1','$avis1','$decision1' )  ");
					
					include ("../vue/page2.php");
					

				 }	
				catch(PDException $e){
					echo "Echec : ".$e->getMessage();
				}

				
		?>

		
	</body>
</html>