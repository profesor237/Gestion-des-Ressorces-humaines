<!DOCTYPE html>
<html>
	<head>
		<title> gestion des enregistrement des fiches de rendement </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=divice-width, initial-scale=1.0">
		
	</head>
	<body>
		<?php
				try{

					$nom1 = $_POST['nom'];
					$fonction1 = $_POST['fonction'];
					$anciennete1 = $_POST['anciennete'];
					$debut1 = $_POST['debut'];
					$fin1 = $_POST['fin'];
					$qualite1 = $_POST['qualite1'];
					$qualite2 = $_POST['qualite2'];
					$qualite3 = $_POST['qualite3'];
					$qualite4 = $_POST['qualite4'];
					$qualite5 = $_POST['qualite5'];
					$qualite6 = $_POST['qualite6'];
					$qualite7 = $_POST['qualite7'];
					$qualite8 = $_POST['qualite8'];
					$qualite9 = $_POST['qualite9'];
					$qualite10 = $_POST['qualite10'];
					$qualite11 = $_POST['qualite11'];
					$qualite12 = $_POST['qualite12'];
					$qualite13 = $_POST['qualite13'];

					$commentaire1 = $_POST['commentaire1'];
					$commentaire2 = $_POST['commentaire2'];
					$commentaire3 = $_POST['commentaire3'];
					$commentaire4 = $_POST['commentaire4'];
					$commentaire5 = $_POST['commentaire5'];
					$commentaire6 = $_POST['commentaire6'];
					$commentaire7 = $_POST['commentaire7'];
					$commentaire8 = $_POST['commentaire8'];
					$commentaire9 = $_POST['commentaire9'];
					$commentaire10 = $_POST['commentaire10'];
					$commentaire11 = $_POST['commentaire11'];
					$commentaire12 = $_POST['commentaire12'];
					$commentaire13 = $_POST['commentaire13'];



					$commentaires = array($commentaire1, $commentaire2, $commentaire3,
					$commentaire4, $commentaire5, $commentaire6, $commentaire7, $commentaire8,
					$commentaire9, $commentaire10, $commentaire11, $commentaire12, $commentaire13);

					$qualites = array($qualite1, $qualite2, $qualite3,
					$qualite4, $qualite5, $qualite6, $qualite7, $qualite8,
					$qualite9, $qualite10, $qualite11, $qualite12, $qualite13);
					$criteres=array();

					$identifiant=0;
					$identifiant1=0;
					$critere1="";
					$i=0;
					


					$connexion = new PDO("mysql:host=localhost; dbname=PROJET1", "root","");
				    $connexion-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

					$requete = $connexion -> exec("INSERT INTO profil (nom,fonction,anciennete,date_debut,date_fin) VALUES('$nom1','$fonction1','$anciennete1','$debut1','$fin1')  ");

					$requete1= $connexion->query(" SELECT id FROM profil WHERE nom='$nom1' ");
            		while($resultat1 = $requete1->fetch()){
						$identifiant=$resultat1['id'];
					
					}


					
					$requete2= $connexion->query(" SELECT intitule, id FROM form ");
            		while($resultat2 = $requete2->fetch()){
						
						$identifiant1=$resultat2['id'];
						if( $identifiant1==2 ||  $identifiant1==5 ||  $identifiant1==9 ||  $identifiant1==13)
						{
							
							
						}
						else
						{

							$qualite=$qualites[$i];
							$commentaire=$commentaires[$i];
							$critere1=$resultat2['intitule'];

							$requete = $connexion -> exec("INSERT INTO evaluation(critere,valeur,commentaire,id_p) VALUES('$critere1','$qualite','$commentaire','$identifiant')  ");
							$i=$i+1;
						}
					
					}

				}
				catch(PDException $e){
					echo "Echec : ".$e->getMessage();
				}


				include ("../vue/page1.php");
					
		?>


		
		
	</body>
</html>