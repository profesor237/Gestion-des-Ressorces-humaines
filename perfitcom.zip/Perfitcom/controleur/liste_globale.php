<!DOCTYPE HTML>
<html>
	<head>
		<title> gestion des ressources humaines </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=divice-width, initial-scale=1.0">
		<link rel="stylesheet" href="styles/style.css">
        <link rel="stylesheet" href="styles/w3.css">
    </head>
	<body>
    <?php
        include('entete.php');

    ?>

    <?php
        try{

            $connexion = new PDO("mysql:host=localhost; dbname=projet1","root","");
            $connexion->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);


            $requete2= $connexion->query(" SELECT id, nom, fonction, anciennete, date_debut, date_fin FROM profil  ");
            while($resultat2 = $requete2->fetch()){
                
            
            
            
            }


            echo'
            <div style="width: 90%; margin-left:40px; ">
            <h2>Listing des fiches d evaluation globale enregistrées</h2>

            <table class="w3-table w3-striped w3-bordered w3-border" style="font-size: 18px">
            <thead>
            <tr class="w3-lime">
             <th> Numéro</th>
              <th> Nom</th>
              <th> mois</th>

              
            </tr>
            </thead>';

            $requete2= $connexion->query(" SELECT  id, nom, mois FROM evaluationglobal  ");
            while($resultat2 = $requete2->fetch()){
                
                echo'
                
            <tr>
                <td>'.$resultat2['id'].'</td>
              <td>'.$resultat2['nom'].'</td>
              <td>'.$resultat2['mois'].'</td>

              
            </tr>

            
            
                
                ';
            
            
            }



        }
        catch(PDOException $e){
            echo " Echec : " .$e->getMessage();
           }


         echo'  </table></div> <br><br><br>';
    ?>

    </body>

</html>
