
<!DOCTYPE HTML>
<html>
	<head>
		<title> gestion des ressources humaines </title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=divice-width, initial-scale=1.0">
		<link rel="stylesheet" href="styles/style.css">
        <link rel="stylesheet" href="styles/w3.css">
	<body>

    <?php
			include ("entete.php");
	?>

    <?php
echo"<div class='corps'>";
try
{
    echo"	
    
        
    <div class='comp1'>
            <h4>
               <strong> SERVICE DES RESSOURCES HUMAINES</strong>
            </h4> 
        </div>
        <div class='comp2'>
            <h4> 
            <strong><u>FICHE D’EVALUATION DU RENDEMENT DU PERSONNEL ADMINISTRATIF</u> </strong>

            </h4>
        </div>
        <div>
            <form  method='post' action= '../controleur/controleur_page1.php'>

                <label ><strong>NOMS ET PRENOMS:</label>
                <input type='text'  name='nom' size='90' class='input1' 
                placeholder='......................................................................................' style='font-size: 16px' required> </input><br><br>
                <label >FONCTION:</label>
                <input type='text' id='lname' name='fonction' size='90' class='input1'
                placeholder='........................................................................................................' style='font-size: 16px' required><br><br>
                <label >Ancienneté au poste:</label>
                <input type='text' id='lname' name='anciennete' size='90' class='input1'
                placeholder='.................................................................................' style='font-size: 16px' required><br><br>
                <label >Période d’évaluation: du</label>
                <input  type='date' name='debut' size='30' style='font-size: 16px' required>
                <label >    au    </label>
                <input type='date' id='lname' name='fin' size='30' style='font-size: 16px' required>
           
        </div>
        <div>
            <h4>
            LEGENDE D’EVALUATION </strong>
            </h4>
            <div>
                <ul>
                    <li style='margin-left: 100px';> 1 = Ne rencontre pas les attentes <br>  3 = Rencontre les attentes    </li>
                    <li class='legende'>2 = Nécessite une amélioration <br>  4 = Depasse les attentes </li>
 
                </ul>

            </div>  
            
        </div><br>

        <div>

        </div>";

        echo' <table border="1" class="w3-table" id="tab" >
        <tr style="background-color: red">
        <th class="intitule"> CRITERES </th>
        <th> 
            <table>
                <tr> EVALUATION </tr>
                <tr> <th>1</th><th>2</th><th>3</th><th>4</th></tr>
            </table>
        </th>
        <th class="commentaire" style="text-align: center"> COMMENTAIRES</th>
        </tr>
        
        ';
        



            $connexion = new PDO("mysql:host=localhost; dbname=projet1","root","");
            $connexion->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

            $i=0;

            $requete1= $connexion->query(" SELECT intitule, id FROM form");
            while($resultat1 = $requete1->fetch()){

                $identifiant = $resultat1['id'];
                
                if( $identifiant==2 ||  $identifiant==5 ||  $identifiant==9 ||  $identifiant==13)
                {
                    echo '<tr style="background-color: yellow">
                    <th class="intitule">'.$resultat1['intitule'].'</th>
                    <th> 
                        <table>
                        <tr>
                        <th></th><th></th> <th></th> <th></th>
                       </tr>
                        </table>
                    </th>
                    <th class="commentaire" > 
                    </th>
                    </tr>';

                }
                else{
                    $i=$i+1;

                    echo '<tr>
                <th class="intitule">'.$resultat1['intitule'].'</th>
                <th> 
                    <table>
                    <tr>
                        <input style="margin-left: 10px" class="radio" type="radio" name="qualite'.$i.'" value="Ne rencontre pas les attentes" required> 
                        <input style="margin-left: 14px" class="radio" type="radio" name="qualite'.$i.'" value="Nécessite une amélioration" required>
                        <input style="margin-left: 14px" class="radio" type="radio" name="qualite'.$i.'" value="Rencontre les attentes" required>
                        <input style="margin-left: 18px" class="radio" type="radio" name="qualite'.$i.'" value="Depasse les attentes" required> 
                    
                   </tr>
                    </table>
                </th>
                <th class="commentaire" >
                    <textarea  class="incom" name="commentaire'.$i.'" style="font-size: 16px" required>  </textarea>
                </th>
                  
                </tr>  ' ;
                
                }
              
                
            }


        }
        catch(PDOException $e){
            echo " Echec : " .$e->getMessage();
           }

        ?>

       </table><p style="margin-left: 80%"> <button class="w3-btn w3-blue" type="submit">Valider </button> </p></form> <div><br><br>

    </body>
            <footer class="w3-container w3-green" style="width: 105%; margin-left: 0px;">
        <h5>GRH</h5>
        <p>Evaluation des employés</p>
    </footer>
    
</html>