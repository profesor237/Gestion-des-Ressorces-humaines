<!DOCTYPE html>
<html>
<title>Accueil</title>


<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="styles/w3.css">

<style>
    .w3-row {height: 500px}
        
    .w3-col.m2, w3-col.m2 {height: 100%;}
        
    @media screen and (max-width: 601px) {
    .w3-row {height:auto;} 
    }
</style>

<body>



    <div class="w3-topnav w3-large w3-green">
    <div class="w3-container w3-section">
    <div class="w3-tag w3-jumbo w3-red w3-animate-top">R</div>
    <div class="w3-tag w3-jumbo w3-animate-top" >H</div>

        <div class="w3-tag w3-round w3-green" style="padding:3px 3px">
        <div class="w3-tag w3-round w3-green w3-animate-bottom" style="border:1px solid white ">
        GESTION DES RESSOURCES HUMAINES
        </div>
        </div>
    </div>
    <a href="accueil.php" style="font-size: 25px"><strong>Accueil<strong></a>

    </div>

<div class="w3-center">    
  <div class="w3-row">
    <div class="w3-col m2 w3-light-grey w3-left" syle="text-align:  left">
        
      <p syle="text-align:  left"><button onclick="document.getElementById('id01').style.display='block'"  style="text-decoration: none">Rechercher une fiche de rendement</button></p>
      <p syle="text-align:  left"><button onclick="document.getElementById('id02').style.display='block'" style="text-decoration: none">Rechercher une fiche d'évaluation globale</button></p><br>
      <p syle="text-align:  left" ><button  style="text-decoration: none"><a href="liste_rendement.php" style="text_decoration: none">Liste exaustive des fiches de rendement </a></button></p>
      <p syle="text-align:  left" style="text_decoration: none"><button  style="text-decoration: none"><a href="liste_globale.php" style="text_decoration: none">Liste exaustive des fiches d'évaluation globale </a></button></p>
    </div>
    <div class="w3-col m8 w3-container"> 
      <h1 class="w3-animate-right"> <div class="w3-tag w3-lime">Statistiques</div></h1>
      <p class="w3-justify">
        <br>

        <?php
            try{

                $total3=0;
                $connexion = new PDO("mysql:host=localhost; dbname=PROJET1", "root","");
                $connexion-> setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

                $requete1= $connexion->query(" SELECT COUNT(id) AS nombre FROM profil ");
            		while($resultat1 = $requete1->fetch()){
						$total=$resultat1['nombre'];
					
                    }
                    
                $requete2= $connexion->query(" SELECT COUNT(id) AS nombre FROM evaluationglobal ");
            	while($resultat2 = $requete2->fetch()){
					$total2=$resultat2['nombre'];
					
                }
                
                $requete3= $connexion->query(" SELECT nom  FROM profil GROUP BY nom ");
            	while($resultat3 = $requete3->fetch()){
					$total3=$total3+1;
					
				}

             }	
            catch(PDException $e){
                echo "Echec : ".$e->getMessage();
            }


       echo' <div class="w3-container w3-pale-blue w3-leftbar w3-border-blue" style="text-align: left">
                <p>Nombre total de fiche de rendement du personnel :      <strong style="font-size: 30px"> '.$total.'

                </strong></p>
        </div>

        <br>
        <div class="w3-container w3-pale-yellow w3-leftbar w3-border-yellow " style="text-align: left">
            <p>Nombre total de fiches d évaluation globale :      <strong style="font-size: 30px"> '.$total2.'

            </strong> </p>
        </div>
        <br>
            <div class="w3-container w3-pale-green w3-leftbar w3-border-green" style="text-align: left">
            <p>Total des employés :     <strong style="font-size: 30px"> '.$total3.'

            </strong> </p>
        </div>';
?>

     </p>
      <hr>
      <h3 class="w3-animate-opacity w3-animate-left">
        <span class="w3-tag w3-black">G</span>
        <span class="w3-tag w3-black">L</span>
        <span class="w3-tag w3-black">O</span>
        <span class="w3-tag w3-black">B</span>
        <span class="w3-tag w3-black">A</span>
        <span class="w3-tag w3-black">L</span>
        <span class="w3-tag w3-green">S</span>
        <span class="w3-tag w3-green">T</span>
        <span class="w3-tag w3-green">O</span></Video>
        <span class="w3-tag w3-green">R</span></Video>
        <span class="w3-tag w3-green">E</span></Video>
      </h3>
    </div>
    <div class="w3-col m2 w3-light-grey w3-padding">
      <div class="w3-card-2 w3-padding">
        <p><a href="page1.php" style="text-decoration: none"> Editer une Fiche de rendement </a></p>
      </div><br>
      <div class="w3-card-2 w3-padding" >
        <p> <a href="page2.php" style="text-decoration: none">Editer uneFiche d'evaluation globale </a></p>
      </div>

    </div>
  </div>
</div>


        <div id="id01" class="w3-modal">
        <div class="w3-modal-content">
            <header class="w3-container w3-teal"> 
            <span onclick="document.getElementById('id01').style.display='none'" 
            class="w3-closebtn">×</span>
            <h2>Rechercher une fiche de rendement administratif</h2>
            </header>
            <div class="w3-container">
            <form method="post" action="affiche_rendement.php" class="w3-container">

                <h2>Indices de recherche</h2>

                <p>      
                <input class="w3-input" type="text" name="nom" required>
                <label class="w3-label w3-validate">Noms et Prénoms</label></p>

                <p>      
                <input class="w3-input" type="date" name="debut" required>
                <label class="w3-label w3-validate">Date de début de la période d'évaluation</label></p>

                <p>      
                <input class="w3-input" type="date" name="fin" required>
                <label class="w3-label w3-validate">Date de fin de la période d'évaluation</label></p>

                <p>      
                <button class="w3-btn w3-teal">Rechercher</button></p>

            </form>

            </div>
            <footer class="w3-container w3-teal">
            <p>GHR</p>
            </footer>
        </div>
        </div>

        <div id="id02" class="w3-modal">
        <div class="w3-modal-content">
            <header class="w3-container w3-teal"> 
            <span onclick="document.getElementById('id02').style.display='none'" 
            class="w3-closebtn">×</span>
            <h2>Rechercher une fiche d'évaluation globale</h2>
            </header>
            <div class="w3-container">
            <form method="post" action="affiche_global.php" class="w3-container">

                <h2>Indices de recherche</h2>

                <p>      
                <input class="w3-input" type="text" name="nom" required>
                <label class="w3-label w3-validate">Noms et Prénoms</label></p>

                <p>      
                <input class="w3-input" type="text" name="mois" required>
                <label class="w3-label w3-validate">Mois</label></p>

                <p>      
                <button class="w3-btn w3-teal">Rechercher</button></p>

            </form>
            </div>
            <footer class="w3-container w3-teal">
            <p>GHR</p>
            </footer>
        </div>
        </div>

<footer class="w3-container w3-green">
  <h5>GRH</h5>
  <p>Evaluation des employés</p>
</footer>
</body>

</html> 
